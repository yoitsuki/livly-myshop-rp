// Card Uploader - 生画像クロップ/結合ユーティリティ
// canvas ベースの純粋な画像処理
// index.html から <script src="crop.js"></script> で読み込み、
// window.CardUploaderCrop 名前空間で公開する。
(function (global) {
  'use strict';

  // ---- 内部ヘルパー ----

  function loadImage(file) {
    return new Promise(function (resolve, reject) {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = function () {
        resolve({ img: img, url: url });
      };
      img.onerror = function (err) {
        URL.revokeObjectURL(url);
        reject(err);
      };
      img.src = url;
    });
  }

  function canvasToFile(canvas, name) {
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (blob) {
        if (!blob) return reject(new Error('toBlob failed'));
        resolve(new File([blob], name || 'out.jpg', { type: 'image/jpeg' }));
      }, 'image/jpeg', 1.0);
    });
  }

  function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
  }

  function normalizeHex(hex) {
    const h = String(hex || '').trim();
    return /^#[0-9a-fA-F]{6}$/.test(h) ? h : '#473939';
  }

  // ---- 公開 API ----

  // 矩形クロップ
  // rect: { x, y, w, h } (入力画像のピクセル座標)
  function cropImage(file, rect) {
    return loadImage(file).then(function (loaded) {
      const img = loaded.img;
      const x = clamp(Math.round(rect.x || 0), 0, img.width);
      const y = clamp(Math.round(rect.y || 0), 0, img.height);
      const w = clamp(Math.round(rect.w || 0), 1, img.width - x);
      const h = clamp(Math.round(rect.h || 0), 1, img.height - y);
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, x, y, w, h, 0, 0, w, h);
      URL.revokeObjectURL(loaded.url);
      return canvasToFile(canvas, 'cropped.jpg');
    });
  }

  // 上下カット (top/bottom はピクセル値)
  function trimImage(file, topPx, bottomPx) {
    return loadImage(file).then(function (loaded) {
      const img = loaded.img;
      const top = clamp(Math.round(topPx || 0), 0, img.height);
      const bottom = clamp(Math.round(bottomPx || 0), 0, img.height - top);
      const h = Math.max(1, img.height - top - bottom);
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, top, img.width, h, 0, 0, img.width, h);
      URL.revokeObjectURL(loaded.url);
      return canvasToFile(canvas, 'trimmed.jpg');
    });
  }

  // 複数ファイルを縦連結 (幅は最大幅に揃え、各画像は左詰めで配置)
  function stackVertical(files, bgHex) {
    if (!files || files.length === 0) return Promise.resolve(null);
    return Promise.all(files.map(loadImage)).then(function (loadedList) {
      const imgs = loadedList.map(function (l) { return l.img; });
      const W = imgs.reduce(function (acc, im) { return Math.max(acc, im.width); }, 0);
      const H = imgs.reduce(function (acc, im) { return acc + im.height; }, 0);
      const canvas = document.createElement('canvas');
      canvas.width = W;
      canvas.height = H;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = normalizeHex(bgHex);
      ctx.fillRect(0, 0, W, H);
      let y = 0;
      for (let i = 0; i < imgs.length; i++) {
        ctx.drawImage(imgs[i], 0, y);
        y += imgs[i].height;
      }
      loadedList.forEach(function (l) { URL.revokeObjectURL(l.url); });
      return canvasToFile(canvas, 'stack.jpg');
    });
  }

  // 左右2枚を横連結 (既存 combine と同じ)
  function joinHorizontal(leftFile, rightFile, bgHex) {
    return Promise.all([loadImage(leftFile), loadImage(rightFile)]).then(function (pair) {
      const l = pair[0].img;
      const r = pair[1].img;
      const canvas = document.createElement('canvas');
      canvas.width = l.width + r.width;
      canvas.height = Math.max(l.height, r.height);
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = normalizeHex(bgHex);
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(l, 0, 0);
      ctx.drawImage(r, l.width, 0);
      URL.revokeObjectURL(pair[0].url);
      URL.revokeObjectURL(pair[1].url);
      return canvasToFile(canvas, 'joined.jpg');
    });
  }

  // 3 行 × 2 列のグリッドから最終画像を合成
  // cells: { left: [ [File,...], [File,...], [File,...] ],
  //          right: [ [File,...], [File,...], [File,...] ] }
  // - 各セル内のファイル配列は「そのセルに積まれた断片」を追加順に縦連結
  // - 左列 3 セルを更に縦連結 → leftStack
  // - 右列 3 セルを更に縦連結 → rightStack
  // - 右列が空なら leftStack を返す
  // - 両方あれば joinHorizontal(leftStack, rightStack)
  //
  // 戻り値: { file: File, leftWidth: number } | null
  //   leftWidth は背景色正規化で「アイコン領域として除外」すべき横幅 (px)
  //     - 単一列のみ (左のみ / 右のみ) の場合: その列の全幅
  //     - 左右両方の場合: 左列の幅 (右列はアイコン行がないので正規化対象)
  function composeGrid(cells, bgHex) {
    const bg = normalizeHex(bgHex);
    const leftCols = (cells && cells.left) || [[], [], []];
    const rightCols = (cells && cells.right) || [[], [], []];

    function stackColumn(colCells) {
      // 各セルを先に縦連結 → その結果を更に縦連結
      const nonEmpty = colCells.filter(function (c) { return c && c.length > 0; });
      if (nonEmpty.length === 0) return Promise.resolve(null);
      return Promise.all(nonEmpty.map(function (c) { return stackVertical(c, bg); }))
        .then(function (cellFiles) {
          return stackVertical(cellFiles, bg);
        });
    }

    function getWidth(file) {
      return loadImage(file).then(function (loaded) {
        const w = loaded.img.width;
        URL.revokeObjectURL(loaded.url);
        return w;
      });
    }

    return Promise.all([stackColumn(leftCols), stackColumn(rightCols)]).then(function (res) {
      const leftFile = res[0];
      const rightFile = res[1];
      if (!leftFile && !rightFile) return null;
      if (leftFile && !rightFile) {
        return getWidth(leftFile).then(function (w) { return { file: leftFile, leftWidth: w }; });
      }
      if (!leftFile && rightFile) {
        return getWidth(rightFile).then(function (w) { return { file: rightFile, leftWidth: w }; });
      }
      // 左右両方: 左列の幅を取ってから横連結
      return getWidth(leftFile).then(function (lw) {
        return joinHorizontal(leftFile, rightFile, bg).then(function (joined) {
          return { file: joined, leftWidth: lw };
        });
      });
    });
  }

  // 隣接画像のオーバーラップ検出
  // prev の下端から最大 maxShift px を next の上端に重ねて SSD を計算し、
  // 最小 SSD のオフセットを返す。閾値を超えた場合は 0 (= 重複なし) を返す。
  //
  // 戻り値: { prevBottomTrim: 0, nextTopTrim: K } (直前画像の内容を優先する方針)
  function detectOverlap(prevFile, nextFile, options) {
    const opts = options || {};
    const maxShiftRatio = opts.maxShiftRatio != null ? opts.maxShiftRatio : 0.6;
    const sampleStep = opts.sampleStep || 8;
    const matchThreshold = opts.matchThreshold != null ? opts.matchThreshold : 200; // per-pixel SSD 平均のしきい値

    return Promise.all([loadImage(prevFile), loadImage(nextFile)]).then(function (pair) {
      const prev = pair[0].img;
      const next = pair[1].img;
      const W = Math.min(prev.width, next.width);
      const maxShift = Math.min(
        Math.floor(prev.height * maxShiftRatio),
        Math.floor(next.height * maxShiftRatio)
      );

      if (W <= 0 || maxShift <= 4) {
        URL.revokeObjectURL(pair[0].url);
        URL.revokeObjectURL(pair[1].url);
        return { prevBottomTrim: 0, nextTopTrim: 0 };
      }

      // prev の下部と next の上部をそれぞれオフスクリーン canvas に描く
      const prevCan = document.createElement('canvas');
      prevCan.width = W;
      prevCan.height = maxShift;
      const prevCtx = prevCan.getContext('2d');
      prevCtx.drawImage(
        prev,
        0, prev.height - maxShift, W, maxShift,
        0, 0, W, maxShift
      );
      const prevData = prevCtx.getImageData(0, 0, W, maxShift).data;

      const nextCan = document.createElement('canvas');
      nextCan.width = W;
      nextCan.height = maxShift;
      const nextCtx = nextCan.getContext('2d');
      nextCtx.drawImage(
        next,
        0, 0, W, maxShift,
        0, 0, W, maxShift
      );
      const nextData = nextCtx.getImageData(0, 0, W, maxShift).data;

      URL.revokeObjectURL(pair[0].url);
      URL.revokeObjectURL(pair[1].url);

      // shift k: prev の最後 k 行が next の先頭 k 行と一致するか
      // k = 1 .. maxShift
      let bestK = 0;
      let bestScore = Infinity;
      const minK = 8; // 小さすぎる k は誤検出するので除外

      for (let k = minK; k <= maxShift; k += 1) {
        // prev の (maxShift - k) .. (maxShift - 1) 行
        //  ↕ 比較
        // next の 0 .. (k - 1) 行
        let sum = 0;
        let count = 0;
        for (let row = 0; row < k; row++) {
          const py = maxShift - k + row;
          const ny = row;
          for (let x = 0; x < W; x += sampleStep) {
            const pi = (py * W + x) * 4;
            const ni = (ny * W + x) * 4;
            const dr = prevData[pi] - nextData[ni];
            const dg = prevData[pi + 1] - nextData[ni + 1];
            const db = prevData[pi + 2] - nextData[ni + 2];
            sum += dr * dr + dg * dg + db * db;
            count++;
          }
        }
        const score = count === 0 ? Infinity : sum / count;
        if (score < bestScore) {
          bestScore = score;
          bestK = k;
        }
      }

      if (bestScore > matchThreshold || bestK === 0) {
        return { prevBottomTrim: 0, nextTopTrim: 0, score: bestScore };
      }
      return { prevBottomTrim: 0, nextTopTrim: bestK, score: bestScore };
    });
  }

  // 指定幅にリサイズ (縦横比維持)。等幅なら元ファイルをそのまま返す。
  function resizeToWidth(file, targetWidth) {
    return loadImage(file).then(function (loaded) {
      const img = loaded.img;
      if (img.width === targetWidth) {
        URL.revokeObjectURL(loaded.url);
        return file;
      }
      const scale = targetWidth / img.width;
      const targetHeight = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
      URL.revokeObjectURL(loaded.url);
      return canvasToFile(canvas, 'resized.jpg');
    });
  }

  // 画像ファイルの幅・高さを取得
  function getImageSize(file) {
    return loadImage(file).then(function (loaded) {
      const w = loaded.img.width;
      const h = loaded.img.height;
      URL.revokeObjectURL(loaded.url);
      return { width: w, height: h };
    });
  }

  global.CardUploaderCrop = {
    cropImage: cropImage,
    trimImage: trimImage,
    stackVertical: stackVertical,
    joinHorizontal: joinHorizontal,
    composeGrid: composeGrid,
    detectOverlap: detectOverlap,
    resizeToWidth: resizeToWidth,
    getImageSize: getImageSize,
  };
})(window);
