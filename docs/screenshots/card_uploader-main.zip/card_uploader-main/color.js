// Card Uploader - 色置換ユーティリティ (HSV 色相方式)
// canvas ベースの純粋な画像処理（生成 AI 不使用）
// index.html から <script src="color.js"></script> で読み込み、
// window.CardUploaderColor 名前空間で公開する。
(function (global) {
  'use strict';

  // "#rrggbb" → [r, g, b]
  function hexToRgb(hex) {
    const h = String(hex || '').trim();
    if (!/^#[0-9a-fA-F]{6}$/.test(h)) return [71, 57, 57]; // fallback: #473939
    return [
      parseInt(h.slice(1, 3), 16),
      parseInt(h.slice(3, 5), 16),
      parseInt(h.slice(5, 7), 16),
    ];
  }

  // r, g, b: 0-255 → [h (0-360), s (0-255), v (0-255)]
  // 彩度 / 明度を 0-255 に揃えることで、しきい値を色相 (°) と同じスケールで扱える。
  function rgbToHsv(r, g, b) {
    const rn = r / 255, gn = g / 255, bn = b / 255;
    const max = Math.max(rn, gn, bn);
    const min = Math.min(rn, gn, bn);
    const delta = max - min;
    let h = 0;
    if (delta > 0) {
      if (max === rn) h = ((gn - bn) / delta) % 6;
      else if (max === gn) h = (bn - rn) / delta + 2;
      else h = (rn - gn) / delta + 4;
      h *= 60;
      if (h < 0) h += 360;
    }
    const s = max === 0 ? 0 : delta / max;
    const v = max;
    return [h, s * 255, v * 255];
  }

  // HSV 判定: 色相 (環状差) ≤ threshold° かつ 彩度差 ≤ threshold かつ 明度差 ≤ threshold
  // (彩度・明度は 0-255 スケール)
  //
  // file: Blob/File (image) → Promise<File>
  function normalizeBackgroundColor(file, options) {
    const {
      targetHex = '#473939',
      threshold = 25,
      excludeRect = null, // { x, y, w, h } — この矩形内は置換しない
    } = options || {};

    return new Promise(function (resolve, reject) {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = function () {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const d = imageData.data;
        const W = canvas.width;

        const [tr, tg, tb] = hexToRgb(targetHex);
        const [tH, tS, tV] = rgbToHsv(tr, tg, tb);

        const ex0 = excludeRect ? excludeRect.x : 0;
        const ey0 = excludeRect ? excludeRect.y : 0;
        const ex1 = excludeRect ? excludeRect.x + excludeRect.w : 0;
        const ey1 = excludeRect ? excludeRect.y + excludeRect.h : 0;

        for (let i = 0; i < d.length; i += 4) {
          if (excludeRect) {
            const p = i / 4;
            const px = p % W;
            const py = (p - px) / W;
            if (px >= ex0 && px < ex1 && py >= ey0 && py < ey1) continue;
          }
          const [pH, pS, pV] = rgbToHsv(d[i], d[i + 1], d[i + 2]);
          let dh = Math.abs(pH - tH);
          if (dh > 180) dh = 360 - dh;
          if (dh <= threshold &&
              Math.abs(pS - tS) <= threshold &&
              Math.abs(pV - tV) <= threshold) {
            d[i] = tr; d[i + 1] = tg; d[i + 2] = tb;
          }
        }

        ctx.putImageData(imageData, 0, 0);
        canvas.toBlob(function (blob) {
          URL.revokeObjectURL(url);
          resolve(new File([blob], file.name || 'normalized.jpg', { type: 'image/jpeg' }));
        }, 'image/jpeg', 1.0);
      };
      img.onerror = function (err) {
        URL.revokeObjectURL(url);
        reject(err);
      };
      img.src = url;
    });
  }

  global.CardUploaderColor = {
    normalizeBackgroundColor: normalizeBackgroundColor,
    hexToRgb: hexToRgb,
    rgbToHsv: rgbToHsv,
  };
})(window);
