// Card Uploader - 許可ステータス一覧
// 通常ステータス / セット効果ステータス それぞれの許可リストを提供。
// index.html / Gemini プロンプト / コピー用チップ / 登録前チェックで共通利用する。
// window.CardUploaderStats 名前空間で公開。
(function (global) {
  'use strict';

  // 通常ステータス (enhancement が "0" / "+9" / "+12" / "+15" / "+18" の行)
  const ALLOWED_STATS = [
    '攻撃%', '会心率', '会心ダメージ', '防御無視', 'ダメージ倍率',
    '対ボス与ダメ増', '対高HP与ダメ増', '対低HP与ダメ増', '状態異常与ダメ増',
    '命中率', '状態異常命中率', '防御%', 'HP%', 'ガード率', '回避率',
    '会心率耐性', '会心ダメ耐性', '対高低HPダメ耐性', '対ボス被ダメ減',
    '状態異常耐性', '状態異常ダメ耐性', '与治療効果', '被治療効果', 'HP吸収率',
    '対○○与ダメ増', '対○○被ダメ減',
  ];

  // セット効果 (enhancement === "Set") で許可するステータス
  // 画像に書かれている表記をそのまま許容する想定 (% 有無 / 漢字表記揺れ を含む)
  // 注意: 「戦力+XXX」はプロンプト側で出力対象外と指示しているため、
  // ここにも含めない (誤って出力された場合に警告で気付けるように)。
  const ALLOWED_SET_STATS = [
    // 通常リストと同じ名前を受けるケース
    ...ALLOWED_STATS,
    // Set 特有の表記 (% 無しの素の名前も含む)
    '攻撃', 'HP', '防御',
    '与ダメージ増加', '被ダメージ減少',
    '対全職業与ダメ増', '対全職業被ダメ減',
    '対○○与ダメ増', '対○○被ダメ減',
    '破勢', '威圧',
  ];

  // ユーティリティ: 重複除去
  function unique(arr) {
    const s = new Set();
    const out = [];
    for (const v of arr) { if (!s.has(v)) { s.add(v); out.push(v); } }
    return out;
  }

  global.CardUploaderStats = {
    ALLOWED_STATS: unique(ALLOWED_STATS),
    ALLOWED_SET_STATS: unique(ALLOWED_SET_STATS),
  };
})(window);
