# 引継ぎ書 — リヴリー マイショップ 参考価格めも (viewer)

新しい Claude セッションで作業を続けるためのコンテキスト。
**最新セッションが落ちた場合、まずこのファイルを読んでから着手すること。**

---

## 1. 何を作っているか

リヴリーアイランド「マイショップ」出品画面のスクショから admin (`yoitsuki/livly-myshop-rp-m`)
が登録した参考価格データを、**誰でも閲覧できる公開ページとして配信する viewer** です。

- 主用途: スマホで見る (mobile-first)
- 認証なし、書き込みコードなし、ホーム + 詳細の 2 ページのみ
- 同じ Firebase プロジェクト (`livly-myshop-ref`) を参照
- 管理アプリと同じ Atelier デザインで開始 (今後は viewer 側で独自進化 OK、admin と同期はしない)

---

## 2. 技術スタック

| 領域 | 採用 | メモ |
|---|---|---|
| フレームワーク | **Next.js 16.2.4 (App Router) + Turbopack** | `pnpm dev` / `pnpm build` |
| 言語 | TypeScript | strict |
| スタイル | **Tailwind CSS v4** | `src/app/globals.css` に CSS 変数 |
| データ取得 | **Firebase Client SDK** (firestore + storage のみ) | `firebase/auth` も `firebase-admin` も入れていない |
| 画面下層 | **`src/lib/firebase/hooks.ts`** | `useItems` / `useItem` / `useTags` — onSnapshot ベース、初回まで `undefined` |
| アイコン | **lucide-react** | |
| フォント | **Cormorant Garamond + Noto Serif JP + Inter + Noto Sans JP** | next/font/google。display=セリフ見出し、body=和文ゴシック、label=Inter |
| UI プリミティブ | `src/components/ui/` | Button / Field / Card / Badge / IconButton / Toast (admin と同形) |
| デザインテーマ | **Atelier** | warm hairline + DEEP TEAL アクセント / 角丸ゼロ / 影なし |
| パッケージ管理 | **pnpm** | |
| PWA | `src/app/manifest.ts` | short_name `参考価格めも` / theme `#006a71` / standalone / `/public/icon.svg` |

> **注意**: `node_modules/next/dist/docs/` の Next.js 16 ガイドに目を通すこと。Next.js 15
> 以前と API/規約が違う可能性がある (CLAUDE.md / AGENTS.md にも記載)。

### admin との差分

admin (`livly-myshop-rp-m` v0.13.0) の以下は **viewer に持ち込んでいない**:

- `firebase/auth` / `AuthProvider` / `LoginScreen`
- `firebase-admin` (サーバ ID トークン検証)
- `dexie` / `dexie-react-hooks` (移行前の遺物)
- `exifr` / `tesseract.js` / `@anthropic-ai/sdk` (OCR / EXIF)
- `react-hook-form` / `zod` / `zustand`
- 書き込みヘルパ全般 (`repo.ts` ごと不採用): `setDoc` / `updateDoc` / `deleteDoc` / `runTransaction` / `writeBatch` / `deleteObject` を **直接呼ぶコードは src/ に存在しない** (Firestore SDK が内部で参照する `runTransaction` 名は bundle に出るが、これは SDK のオフライン永続化レイヤの内部メソッド)。**例外**: v0.2.0 以降は受信BOX アップロード (`src/lib/inboxUpload.ts`) で `uploadBytes` を呼ぶ — Storage `inbox/` への匿名 PUT のみ、Firestore の書き込みは依然ゼロ。
- 編集系ページ: `/register` / `/items/[id]/edit` / `/items/[id]/prices/*` / `/tags` / `/presets` / `/settings` / `/api/claude-ocr`
- `ImageCropper` / `PresetForm` / `PriceEntryForm` / `Fab`

### admin から viewer 用に新設したもの

- `src/lib/firebase/selectors.ts` — `latestPriceEntry` / `sortedPriceEntries` の純粋関数だけ。admin では `repo.ts` に書き込みヘルパと同居していたが、viewer は読みだけなので分離した
- `src/lib/firebase/types.ts` — admin の `types.ts` から `AppSettings` を削除、`ItemCropRecord` が依存していた `CropRect` (本来 `image.ts` 由来) はインライン化

---

## 3. Firebase まわりの仕様

### コレクション (read-only)

| コレクション | ドキュメント形 | 用途 |
|---|---|---|
| `items/{id}` | `Item` | アイテム + `priceEntries[]` を埋込配列で保持 |
| `tags/{id}` | `Tag` | タグ |

`settings/singleton` は admin 専用 (cropPresets) なので viewer は購読しない。

### Storage

**read** (アイテム画像)
- パス: `items/{itemId}/{icon|main}.jpg`
- viewer は Firestore doc の `iconUrl` / `mainImageUrl` (download URL 文字列) を `<img src>` に渡すだけ
- `getDownloadURL` を直接叩く処理も無し (admin が upload 時に書いた値をそのまま使う)

**write** (受信BOX, v0.2.0〜)
- パス: `inbox/{uuid}.{ext}` (フォルダ階層は作らない / 直下のみ)
- 拡張子は `.jpg` / `.png` / `.webp` のいずれか (HEIC は viewer が canvas で JPEG に再エンコードしてから PUT)
- `customMetadata.originalLastModified = String(file.lastModified)` を必ず付ける (admin 側で EXIF が無いときの checkedAt フォールバック)
- contentType はブラウザ報告値そのまま (HEIC 経路は `image/jpeg`)
- 認証なし (Storage Rules で `inbox/*` の create が公開されている)
- 実装: `src/lib/inboxUpload.ts` の `uploadToInbox(file)` のみ。`uploadBytesResumable` は使わない (軽い画像なので `uploadBytes` で十分)

### セキュリティルール

admin 側で以下のルールを Firebase Console に貼り済:

```
function isAdmin() {
  return request.auth != null
      && request.auth.uid == 'zXleLmp8W8OwUH2j7EIg7BNyLXs2';
}

match /items/{id} { allow read: if true; allow write: if isAdmin(); }
match /tags/{id}  { allow read: if true; allow write: if isAdmin(); }
match /b/{bucket}/o/items/{id}/{file} { allow read: if true; allow write: if isAdmin(); }

// Storage (admin v0.17.0 で追加 / size+contentType ガードは admin で v0.3.0 リリース時にデプロイ済)
match /inbox/{file=**} {
  allow read: if true;        // 一覧 + 個別取得を公開
  allow create:
    if request.resource.size <= 10 * 1024 * 1024
    && request.resource.contentType.matches('^image/(jpeg|png|webp)$');
  allow update, delete: if isAdmin();
}
```

つまり viewer は **未認証で read 全部 + Storage `inbox/` への create だけが通る**。viewer 側で追加作業は不要。

### 環境変数

`.env.local.example` がテンプレ。Vercel に同じ Name で登録 (Production / Preview / Development 全部)。

| Name | scope | 用途 |
|---|---|---|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | client | Firebase init |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | client | 同上 |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | client | 同上 |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | client | 同上 |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | client | 同上 |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | client | 同上 |

`NEXT_PUBLIC_ADMIN_UID` も `FIREBASE_SERVICE_ACCOUNT` も viewer には **不要** (書込みも認証も無いため)。

> Vercel のテキスト入力欄に値を貼るとき、`<...>` プレースホルダ表記を一緒にコピペしないよう注意 (admin 側で実際にあった事故)。

---

## 4. 現在のバージョン

`src/lib/version.ts` の `APP_VERSION` を更新する運用。**v0.2.0 以降は home (`/`) ページのフッターに表示** (旧来の Drawer 下部表示は廃止)。

最新: **0.6.1** (branch `claude/fix-home-loading-state-1Nn82`)

直近のチェンジログ:
- **0.6.1 — ホーム一覧の初回ロード状態を LoadingState 化 ( admin v0.26.5 同期 )**
  - `useItems()` は初回 onSnapshot が届くまで `undefined` を返す規約だが、home 側で `items?.length ?? 0` / `items ?? []` と潰していたため、ロード中のごく短い時間でも EmptyState ( 「まだアイテムがありません」/「条件に合うアイテムはありません」 ) が一瞬チラつく不具合があった
  - `loading = items === undefined` を `src/app/page.tsx` のトップで判定。loading 中は **count / sort 行** と **EmptyState / list** をひとまとめに `LoadingState` ( `Loader2` `animate-spin` 28px + 「読み込み中…」を `--font-label` 0.12em tracking で ) に差し替える
  - SearchBar / 絞込みボタンは従来どおり上部に残す。`hasAnyFilterUI = totalCount > 0 || (tags?.length ?? 0) > 0` は `??` で undefined を 0 に倒しているので loading 中は自動で false → 絞込みボタン自体が出ない設計 ( admin と同じ )
  - 本当に items が空 ( `items.length === 0` ) のときだけ EmptyState を出す。検索 / 絞込みでヒット 0 件のときは従来どおり「条件に合うアイテムはありません」が出る ( この経路は loading=false なので従来動作 )
  - **やらない**: 詳細ページ ( `/items/[id]` ) は既に `item === undefined → 読み込み中…` の分岐があるので不変。`useTags` の `tags === undefined` までは待たない方針 — items が出れば一覧自体は描画できる ( admin と同じ判断 )
- **0.6.0 — ホーム絞込みパネルに「クリア」ボタン追加 ( admin v0.25.0 同期 )**
  - `activeFilterCount > 0` のときだけ、絞込みパネル**先頭** ( 最初のセクション = 原本・レプリカ の直前 ) に `[絞込み中 N 件] ............ [× クリア]` の 1 行バーを表示
  - 「クリア」で `replicaFilter='all'` / `activeCategory=null` / `activeTagIds=[]` にまとめてリセット。`activeFilterCount === 0` になるのでバー自身も自動で消える ( 表示条件と同一なので追加 state 不要 )
  - **q ( SearchBar ) は意図的にクリアしない** — 検索文字列を保ったまま絞込みだけ外したいケースに合わせ、`activeFilterCount` が q を除外して数えている既存仕様とも整合。admin 側も同じ判断
  - スタイルは Atelier 既存トークンで揃え ( `--color-line` / `--color-muted` / `--font-label` / 角丸ゼロ / tracked-out uppercase ) 、追加 CSS ゼロ。ボタンは `<X size={12} strokeWidth={1.8} />` + 「クリア」ラベル、mobile ( 375 / 414px ) で折り返さない
  - **やらない / 触らない**: `activeFilterCount` の算出ロジック ( q を除く ) / `FilterToggleButton` 右上のバッジ。q もまとめてリセットしたい派生案は、SearchBar 側の clear と組み合わせる方向で別途 ( ボタン 2 個 / 長押し挙動変更 等 ) — 今回スコープ外
- **0.5.1 — ItemCard 参考価格行を 2 段化 + PeriodBadge コンパクト化 (admin v0.19.1 同期)**
  - 一覧の参考価格行を **ラベル単独行 / 価格 + GP + period badge** の 2 段に分解。`flex-wrap` をやめたので 5〜6 桁の長い価格 ( 例: `120,000–180,000` ) でも badge が折り返さず 1 行に収まる
  - ラベル行と価格行は両方とも `lineHeight: 1` ( Cormorant 18px の暗黙 line-height ≈ 1.5 が作る上余白を殺す ) 。行間は `marginTop: 3` で密着 → ラベル ↔ 価格が同じ "塊" に見える
  - 価格セルは `min-w-0 truncate tabular-nums`、`GP` セルは `shrink-0`、period badge は `ml-auto self-center shrink-0` で右端死守
  - 最低価格行は `marginTop: 8` で別クラスタとして分離 ( 旧 `mt-px` から拡大 — 価格行が締まった分の埋め合わせ )
  - `PeriodBadge` ( `ItemCard` + 詳細 `items/[id]/page.tsx` 両方 ) を 1 段コンパクト化: `fontSize 9.5 → 9` / `letterSpacing 0.16em → 0.08em` / `padding 2px 8px → 2px 5px`。3 tier の配色 ( newest 塗り teal / 2nd 抜き枠 deep / older 抜き枠 muted ) は不変
- **0.5.0 — 情報元 chip を一覧 / 詳細のタグ列末尾に追加 (admin v0.19.0 同期)**
  - `Item.priceEntries[].priceSource` ( 既存フィールド、admin 側が書込済 ) を read してアイテムレベルの「情報元」を chip 表示
  - `src/lib/firebase/selectors.ts` に `infoSourceLabel(item)` を追加 — `mainImageUrl` あり → `マイショ`、なければ最新 priceEntry の `priceSource` ( `なんおし` / `その他` )、未設定の旧データは `設定無し` にフォールバック
  - `src/components/InfoSourceChip.tsx` 新設 — TagChip と同形状の矩形ピル ( `padding: 2px 8px` / `fontSize: 10` / `letterSpacing: 0.06em` / `lineHeight: 1` / `borderRadius: 0` ) だが配色は別: 背景 `#ffffff` 白 + 文字 `var(--color-muted)` + `0.5px solid var(--color-line)` のヘアライン枠。`情報元: {label}` の固定 prefix
  - `ItemCard.tsx` / `items/[id]/page.tsx` のタグ列末尾に `InfoSourceChip` を 1 つ足す。**`itemTags.length === 0` 等の空判定はやめて常時描画** — 情報元はタグ未付与のアイテムにも必ず出す
  - 詳細ページ既存の per-priceEntry の `priceSource` 表示 ( PriceEntryRow の `Calendar` アイコン横、`| {priceSource}` ) は触らず温存。今回追加するのは item レベルのタグ列の chip のみ
  - **やらない**: データモデル変更 / 登録 form 系 / TagChip 配色変更 / Firestore / Storage への書込み — viewer は read-only の方針を維持
- **0.4.0 — レプリカ対応 + ホームフィルタ再構成 (admin v0.18.0–v0.18.2 同期)**
  - **データ層**: `Item` に `isReplica?: boolean` を追加。`itemFromFs` は `data.isReplica === true` のときだけ `true` を拾い、それ以外は `undefined` ( = 原本 ) として読む。truthy 判定で広く拾うと意図しないデータを誤判定するので明示的に。viewer は read-only なので write helper は依然不要。ゲーム内呼称は **「原本」 / 「レプリカ」** ( **「本物」は誤訳 — UI / コミット / コメントすべて「原本」表記** )
  - **REPLICA バッジ** ( `--color-gold-deep` 抜き枠 + 同色テキスト、`--font-label` Inter, 0.22em tracking, 角丸ゼロ、`isReplica === true` のときだけ表示 — 原本にはバッジを出さず既定状態をミニマル維持 )
    - `ItemCard.tsx`: 左カラムを `flex flex-col items-center gap-1` で wrap してアイコン thumb の **直下** にバッジ ( fontSize 8.5 / padding 1px 5px ) を縦に並べる。タイトル隣ではなく画像に視覚的に紐付ける
    - `items/[id]/page.tsx`: タイトルブロックの右側に右寄せ行を新設。**カテゴリの位置を「名前の下・左寄せ」から「名前の上・右寄せ」に変更**、REPLICA バッジ ( fontSize 9.5 / padding 2px 7px、一覧より一段大きい ) を **カテゴリの先 ( 左 ) に並べる**
  - **ホームフィルタ再構成** — `src/app/page.tsx` を全面書き換え
    - ファーストビューは **SearchBar + 件数 + アイテム一覧** だけ。カテゴリ chip 列 / タグ section / 原本レプリカ segment は SearchBar 横の **「絞込み」ボタン** ( `SlidersHorizontal` icon, h=42 で SearchBar と縦サイズ合わせ ) に集約
    - 絞込みボタン右上に **アクティブフィルタ件数バッジ** ( `--color-gold-deep` 塗、Inter, 角丸ゼロ )。q ( 検索文字列 ) は SearchBar 自体に値が見えるので **二重カウント回避でバッジから除外**、`replicaFilter !== "all"` + `activeCategory` + `activeTagIds.length` の合算
    - パネルは SearchBar 直下に **インライン展開** ( hairline border + 白背景 ) 、上から 「原本・レプリカ → カテゴリ → タグ ( 全 type 折り畳まれた状態 ) 」
    - **原本・レプリカ segment** — 「両方 / 原本のみ / レプリカのみ」 ( 既定の「両方」が左端 ) 。3 ボタンの border が 2px 線にならないよう `-ml-px first:ml-0` で重ね、active のとき `relative z-10` で勝たせる。各セグメントに件数表示
    - **件数の取り方**: q / category / tag フィルタを通したあと、replica で絞る前の段階 ( `preReplicaFiltered` ) で計算。これにより「両方」セグメントの数字が "現在の絞り込み済みの全件" になり、UX が直感的に。`replicaCounts` で `original` / `all` / `replica` を一度に出す
    - **タグ section ( type 別 collapsible )** — 各セクション見出し全体がタップ領域、`ChevronRight` の `rotate-90` で開閉表示 ( DrawerNav と同じパターン ) 。default closed、開閉は完全にユーザー操作 ( 旧 SPEC の `useEffect` による auto-expand は **採用しない** )
    - 見出し右端の **賢い「全て選択 / 全て解除」 1 ボタン** — 全タグ active なら「全て解除」、それ以外は「全て選択」。`<button>` ネスト不可なので親見出し button の中に `<span role="button" tabIndex={0}>` + Enter / Space ハンドラ + `e.stopPropagation()` で代用
    - 件数表記は active あれば `${active}/${total}`、なければ `${total}` ( `--color-muted` の控えめ表示 — 旧 SPEC の「N ON」色付き強調は不採用 )
    - 件数 0 のタグはセクションごと非表示 ( ただし「現在選択中」のタグは 0 件でも残して解除導線維持 — 0.3.0 と同じルール )
- **0.3.0 — `/inbox` サムネプレビュー + タグ系を admin v0.15.0–v0.17.5 と同期**
  - `/inbox` のリスト各行の左に 48px atelier-thumb を追加。`URL.createObjectURL(file)` を選択直後に当てて即時プレビュー。HEIC のように `<img>` でデコードできない形式は `onError` で `ImageIcon` プレースホルダにフォールバック (iOS Safari は HEIC を素のまま描けるので実画像が出る)。createObjectURL は page unmount 時に revoke
  - **タグ系刷新** — admin v0.15.0 / 0.16.0 / 0.17.5 のうちコード変更だけで完結するものを取り込み (Firestore の保存値はそのまま)
    - `TagType` を 7 種に: `gacha` / `bazaar` / `nuts` / `gradely` / `collab` / `creators` / `other`。viewer 旧定義は 4 種 (`gacha` / `bazaar` / `shop` / `other`) で、`shop` は admin 0.15.0 で `gradely` に自動置換 + 0.15.2 で移行コード削除済。Firestore に `shop` が残っていても `normalizeTagType` で `other` に倒れるため、未知タイプも含めて UI が落ちない
    - `Tag.displayOrder?: number` を追加
    - `src/lib/tagTypes.ts` を新設 (`TYPE_LABEL` / `TYPE_ORDER` / `TYPE_COLORS` / `normalizeTagType`)。`gacha` のラベルは「ニューマハラショップ」 (display only)
    - `useTags()` の安定ソートを TYPE_ORDER → displayOrder asc (undefined は末尾) → createdAt asc に変更
    - ホームのタグフィルタを **タイプ別セクション** に再構成。各セクションヘッダは Atelier の `--font-label` (Inter, 0.18em uppercase)、各チップ末尾に件数 (tabular-nums) を表示、件数 0 のタグはセクションごと非表示 (ただし「現在選択中」のタグは 0 件でも残して解除導線を維持)
    - `TagChip.tsx` は `TYPE_COLORS` のパレットを参照する形に置換 (背景 + 前景色)。viewer は read-only なので `onRemove` prop は撤去
    - `src/components/TagChip.tsx` の `Tag` 型 import から `TagType` を外した
    - `globals.css` の旧 `--color-pink/mint/sky/lavender` トークンは未使用になったので削除 (`@theme inline` の export も同時撤去)
  - mappers.ts の write 側 (`tagToFs`) は viewer 一貫の方針として **追加しない**。`tagFromFs` のみ `normalizeTagType` + `displayOrder` 読みに更新
- **0.2.0 — 受信BOX アップロード (admin v0.17.0 受信BOX 連携)**
  - ヘッダー右上の Drawer メニューを廃止、代わりに `Upload` アイコン + 小ラベル「アップロード」を配置 → `/inbox`
  - `/inbox` 画面 (新規 `src/app/inbox/page.tsx`) で複数画像を並列アップロード。`<input type="file" accept="image/*" multiple>` → ファイルごとに `送信中 / 送信済み / 失敗` をリスト表示、完了時 Toast (`N 件送信しました`)
  - HEIC は canvas で JPEG に再エンコード、JPEG/PNG/WebP は再エンコードなしで PUT (admin 側の EXIF 解析を生かす)
  - `customMetadata.originalLastModified = String(file.lastModified)` を必ず付ける (`src/lib/inboxUpload.ts`)
  - 10 MB 超 / オフラインは事前拒否 (UX のみ)、アップロード中は `beforeunload` で誤離脱を防止
  - `DrawerNav.tsx` は削除。version 表示は home (`/`) のみのフッターへ移設 (`AppShell` で `pathname === "/"` のときだけレンダー)
  - `/inbox` ページの header からはアップロードアイコンを抑制 (`AppHeader` の `hideUpload` prop) — 重複回避
  - 説明文: 「管理者に画像を送ると確認後に登録されます。」+ 「JPEG / PNG / WebP / HEIC 対応 (HEIC は自動で JPEG に変換)。1 枚あたり 10 MB まで。」
  - **server-side の size / contentType 制限は admin の `storage.rules` に依頼済 (§10 参照) — viewer 側のチェックは UX のみ、改変クライアントには無力**
- **0.1.0 — 初期 scaffold + 詳細ページ調整** (admin v0.13.0 をベースに)
  - 構成: ホーム (一覧 + 検索 + カテゴリチップ + タグフィルタ + ソート) + 詳細 (タイトル / タグ / MIN PRICE / MARKET REFERENCE / マイショップ画像 / メタ)
  - 詳細タイトルブロックは「左にアイコン (64px corner-tick atelier-thumb) / 右に名前 (上) + カテゴリ (下、左寄せ ラベル)」
  - MIN PRICE は `flex-1` と縦線区切りを廃し、ラベルに `minWidth: 96px` を入れて MARKET REFERENCE の参考価格と縦位置を揃える
  - 各 PriceEntry 行の確認日は **「📅 確認日 YYYY-MM-DD HH:MM」** の表記に
  - 詳細ページに `マイショップ画像` の Atelier セクションヘッダ (Inter / `--font-label` / 0.18em / hairline rule) を追加してメイン画像の上に配置
  - DrawerNav はホームリンク 1 件だけ (admin の /tags /presets /settings 等は撤去) — v0.2.0 で削除済

---

## 5. データモデル

`src/lib/firebase/types.ts` が型の正本 (admin の types.ts から `AppSettings` と `../preset` 依存を落とした版)。

```ts
type TagType =
  | "gacha"
  | "bazaar"
  | "nuts"
  | "gradely"
  | "collab"
  | "creators"
  | "other";

interface CropRect { x: number; y: number; width: number; height: number; }

interface ItemCropRecord {
  rect: CropRect;
  source: { width: number; height: number };
  croppedAt: number;
}

interface ShopPeriodRecord {
  yearMonth: string;     // "YYYYMM"
  phase: "ongoing" | "lastDay";
  auto: boolean;
}

interface PriceEntry {
  id: string;
  shopPeriod?: ShopPeriodRecord;
  refPriceMin: number;
  refPriceMax: number;
  checkedAt: number;
  priceSource?: string;  // "なんおし" / "その他"
  createdAt: number;
}

interface Item {
  id: string;
  iconUrl?: string;             // Storage の download URL
  iconStoragePath?: string;
  mainImageUrl?: string;
  mainImageStoragePath?: string;
  iconCrop?: ItemCropRecord;
  mainCrop?: ItemCropRecord;
  name: string;
  category: string;
  tagIds: string[];
  minPrice: number;
  priceEntries: PriceEntry[];   // 常に1件以上 (admin が保証)
  createdAt: number;
  updatedAt: number;
  isReplica?: boolean;          // v0.4.0 — true = レプリカ。undefined / false = 原本 (既定)
}

interface Tag {
  id: string;
  name: string;
  type: TagType;
  color?: string;
  displayOrder?: number;   // v0.3.0 — TYPE_ORDER 内の並び順
  createdAt: number;
}
```

### 読み取り (`src/lib/firebase/hooks.ts`)

- `useItems()` — `items` を `updatedAt desc` で listen
- `useItem(id)` — 単一 doc (`null` = 存在しない / `undefined` = 読込中)
- `useTags()` — `tags` を Firestore からは `createdAt asc` で取り、クライアント側で TYPE_ORDER → `displayOrder asc` (undefined 末尾) → `createdAt asc` の安定ソートを掛け直して返す (v0.3.0〜)

すべて **「初回スナップショットが来るまで undefined を返す」** ので `if (!items) return null` 系の分岐がそのまま使える (admin 由来の規約)。

### Pure helpers (`src/lib/firebase/selectors.ts`)

- `sortedPriceEntries(item)` — `shopPeriod` 降順 → `phase=lastDay` 優先 → `checkedAt` 降順
- `latestPriceEntry(item)` — 上記の先頭
- `infoSourceLabel(item)` (v0.5.0) — `mainImageUrl` あり → `マイショ`、なければ最新 priceEntry の `priceSource`、未設定の旧データは `設定無し`

### 注意

- viewer から書き込みヘルパは輸入しない。新機能で書き込みが必要になったら、それは admin 側でやるべき仕事 (もしくは別エンドポイント) — viewer リポジトリで Firestore 書き込み API を import した瞬間にレイヤ分離が崩れる
- 本ドキュメントは "ローンチ前" を前提に書いていない。admin 側がスキーマを破壊変更したら viewer も追従が必要。`Item` / `PriceEntry` / `Tag` の必須フィールド構成は admin の types.ts と二重管理になっている

---

## 6. ファイル地図

```
src/
  app/
    layout.tsx              ルート: AppShell に直接子を流す (admin の AuthProvider は無し)
    globals.css             Atelier 配色トークン + atelier-thumb / atelier-tick / atelier-row
    manifest.ts             PWA manifest (admin と同じ)
    page.tsx                ホーム = SearchBar + 「絞込み」ボタン (v0.4.0〜) + 件数 / sort + 一覧。絞込みボタンを押すと SearchBar 直下にパネルが展開し、原本・レプリカ segment / カテゴリ chip / type 別 collapsible タグ section が並ぶ。FilterToggleButton / ReplicaSegmentButton / TagSection / CategoryChip / EmptyState を内包 (現状は inline コンポーネント)
    items/[id]/page.tsx     詳細 (タイトル / タグ / MIN PRICE / MARKET REFERENCE / マイショップ画像 / メタ)。v0.4.0 でタイトルブロックのカテゴリ表示位置を「名前の下・左寄せ」→「名前の上・右寄せ」に変更し、`isReplica === true` のとき同じ右寄せ行に REPLICA バッジを並べる。v0.5.0 でタグ列末尾に `InfoSourceChip` を常時描画 ( タグ無しでも出す )
    inbox/page.tsx          受信BOX アップロード (v0.2.0〜): file picker / 並列 upload / per-file status / Toast / beforeunload guard。v0.3.0 で 48px atelier-thumb の即時プレビュー (createObjectURL) + HEIC は onError で ImageIcon フォールバック
  components/
    AppHeader.tsx           ロゴ "LIVLY / MY-SHOP REF" (Link to "/") + back 時に左の戻るアロー + 右に Upload icon + 「アップロード」小ラベル (Link to /inbox)。`hideUpload` prop で /inbox 上では右側を抑制
    AppShell.tsx            usePathname → parentHref で戻るボタンの遷移先解決 + `/inbox` のときに `hideUpload` を立てる + home (`/`) でのみ ver. {APP_VERSION} フッターを表示。main に overflow-x-hidden
    ItemCard.tsx            一覧 1 行 (atelier-row + 64px corner-tick サムネ + Cormorant 名 + 参考/最低価格 + 期間バッジ)。v0.4.0 で左カラムを縦 flex にして、`isReplica === true` のときアイコン thumb の直下に REPLICA バッジ (8.5px / `--color-gold-deep` 抜き枠) を並べる。v0.5.0 でタグ列末尾に `InfoSourceChip` を常時描画。v0.5.1 で参考価格行を 2 段化 (ラベル / 価格 + GP + badge、`lineHeight: 1` + `marginTop: 3` で 1 塊、最低価格は `marginTop: 8` で分離) + PeriodBadge を 9px / 0.08em / `2px 5px` にコンパクト化
    InfoSourceChip.tsx      v0.5.0 — TagChip と同形状の矩形ピル ( 白背景 + muted 文字 + 0.5px hairline + 角丸ゼロ ) 。「情報元: {label}」を表示。label は `infoSourceLabel(item)` で算出
    SearchBar.tsx           検索欄 (admin と同じ)
    TagChip.tsx             desaturated 矩形ピル (v0.3.0 で `TYPE_COLORS` 7 色パレットに切替、`onRemove` 撤去 — viewer は read-only)
    ui/                     共通プリミティブ (admin と同形のまま採用)
      Button.tsx
      Field.tsx             inputClass({ highlighted, error, multiline, fullWidth })
      Card.tsx
      Badge.tsx
      IconButton.tsx
      Toast.tsx
      index.ts
  lib/
    firebase/
      client.ts             遅延 init (firestore() / storage() を関数化、SSG プリレンダ時に getAuth 等が走らないように)。`ADMIN_UID` も `firebaseAuth()` も無し
      mappers.ts            itemFromFs / tagFromFs のみ (Firestore → TS の片道変換)。itemFromFs は v0.4.0 で `data.isReplica === true` のときだけ `true` を読む (それ以外は undefined = 原本)
      hooks.ts              useItems / useItem / useTags (v0.3.0 で TYPE_ORDER → displayOrder → createdAt の安定ソート)
      selectors.ts          latestPriceEntry / sortedPriceEntries / infoSourceLabel (v0.5.0) — 純粋関数
      types.ts              型定義 (v0.3.0 で TagType 7 種化 + Tag.displayOrder 追加 / v0.4.0 で Item.isReplica 追加)
    tagTypes.ts             TYPE_LABEL / TYPE_ORDER / TYPE_COLORS / normalizeTagType (v0.3.0 新設、admin 0.16.0 同形 + 0.17.5 のラベル変更含む)
    inboxUpload.ts          受信BOX アップロード (v0.2.0〜): `uploadToInbox(file)` のみ。HEIC を canvas で JPEG 化、`uploadBytes` + `customMetadata.originalLastModified` で `inbox/{uuid}.{ext}` に PUT。client.ts の `storage()` を再利用
    shopPeriods.ts          SHOP_ROUNDS + resolveShopPeriod + roundAgeIndex (admin と完全同期)
    utils/
      date.ts               formatDate / formatDateTime / toLocalInput / fromLocalInput
      parsePrice.ts         parsePrice / formatPrice
    version.ts              APP_VERSION + 変更履歴コメント
docs/
  DATA_SOURCES.md           https://livly-guide.com/livly-myshop/ 出典記載
  HANDOFF.md                ← このファイル
.env.local                  NEXT_PUBLIC_FIREBASE_* 6 個 (コミット禁止)
.env.local.example          env テンプレ (空値 — コミット可)
```

**削除済 (履歴用)**: `components/DrawerNav.tsx` (v0.1.0 で右からスライドインしていたメニュー、リンクは「ホーム」だけ + フッタに APP_VERSION) — v0.2.0 で右上が `Upload` アイコンに置き換わったため不要に。version 表示は home フッターに移設。

---

## 7. ユーザー (作者) の好み・地雷

admin の HANDOFF からの継承事項。viewer も同じトーンで運用する。

### 進め方
- **作業は小さく** 刻む。複数機能の同時着手より 1 トピック完了 → 確認 → 次
- バージョンは ユーザー目線の変化があったら必ず bump し、`version.ts` のコメントに 1〜3 行で記録
- mobile-first。375〜414 px 幅で見て破綻しないこと
- 過剰な余白を嫌う。一覧は密度高め (カード式は admin で却下済)
- **コミットはこまめに、push はまとめて 1 回** (admin 側のユーザー指示)
- スクショ報告は不要

### UI / 配色トークン (Atelier)
- **warm white** (`--color-cream #ffffff`) ベース、**warm hairline** (`--color-line #e7dfd5`) 区切り、**DEEP TEAL** (`--color-gold #006a71` / `--color-gold-deep #00494e`) 主アクセント、**taupe muted** (`--color-muted #857769`) 副ラベル
- レガシー Tailwind class 名 (`cream` / `beige` / `gold` / `mint` / `pink` 等) は残してあるが CSS 変数の値は Atelier 値
- 角丸ゼロ。`rounded-*` は使わない (新規は `borderRadius: 0` か `rounded-none`)
- 影もゼロ (`--shadow-card` / `--shadow-fab` は `none`、`--shadow-focus` のみ 2px ティールリング)
- フォント 3 軸 (`--font-display` / `--font-body` / `--font-label`)
  - **`--font-display`** = `Cormorant Garamond` + `Noto Serif JP` — タイトル / 名前 / 価格数値
  - **`--font-body`** = `Noto Sans JP` — 本文 / placeholder / 「参考価格」「最低価格」のような本文ラベル
  - **`--font-label`** = `Inter` — トラックアウト極小ラベル (`MIN PRICE` / `MARKET REFERENCE` / セクションヘッダ)
- **`font-bold` / `font-medium` を強調目的では使わない**。強調は display フォントで
- 緑は本物のアクセントだけ (primary CTA / 最新の period badge / focus ring / active drawer 左バー / Cormorant 価格数値・タイトル)
- ヘッダ: 2 行ロゴ "LIVLY" + "MY-SHOP REF"。**ロゴ全体が `Link href="/"`**。右側は `Upload` icon + 縦に並ぶ「アップロード」小ラベル (text-[8.5px], `--color-muted`) で `Link href="/inbox"`。`/inbox` 自身では右側を抑制 (`hideUpload`)
- 戻るボタンは左上の hairline-only icon button、`AppShell.parentHref()` の解決結果に従って `<Link>` (history を汚さない)
- ホーム一覧 (`ItemCard`): corner-tick サムネ (`atelier-thumb`、4 隅にティール 6px ティック) + Cormorant の名前 + 参考/最低価格行 + 期間バッジ右寄せ + タグ
- 詳細 (`items/[id]`): editorial spread。Title block (左 64px アイコン + 右に 「カテゴリ ラベル + (任意) REPLICA バッジ」を右寄せした行 → 名前) → ハッシュタグ → MIN PRICE → MARKET REFERENCE → マイショップ画像見出し → ヒーロー画像 → メタ。v0.4.0 でカテゴリの位置を「名前の下・左寄せ」から「名前の上・右寄せ」に変更
- 期間バッジ 3 段階: 最新 = 塗りつぶし / 一つ前 = 抜き枠 deep / 古い = 抜き枠 muted
- セクションヘッダのヘアライン: `<span className="h-px flex-1 bg-[var(--color-line)]" aria-hidden />` を `flex items-center gap-2` のラベルの右に流す
- `TagChip` は **desaturated 矩形ピル** (0.5px hairline + 角丸ゼロ)。`TagType` は `gacha / bazaar / nuts / gradely / collab / creators / other` の 7 種 (v0.3.0〜)。地色 / 文字色は `src/lib/tagTypes.ts` の `TYPE_COLORS` に集約 — 旧 `--color-pink/mint/sky/lavender` トークンは廃止済

### 機能
- 一覧と詳細ヘッダの参考価格・期間バッジは `latestPriceEntry()` の値を表示
- 戻るボタンは左、右上は v0.1 ではドロワー (右からスライドイン)、**v0.2.0 で `Upload` アイコン + 「アップロード」ラベル** に変更。ドロワー機構は撤去済
- 戻るボタンは `router.back()` ではなく `AppShell.parentHref()` で解決した固定パスへの `<Link>` (admin v0.11.1 と同じ慣習を継承)
- 削除確認ダイアログは `window.confirm()` を使わない (iOS Safari standalone PWA で無音失敗) — viewer に確認ダイアログは現状無いが、将来追加するときも `confirm()` 禁止
- ボタンには `<button type="button">` を明示

### 避けるべきこと
- description フィールド (admin で過去にあったが削除済)
- emoji を UI に直接書く (lucide アイコン)
- `firebase/auth` / `firebase-admin` を viewer に持ち込む (公開閲覧という性質を壊す)

---

## 8. ハマりやすいポイント (admin から継承 + viewer 固有)

| 症状 | 原因 | 対処 |
|---|---|---|
| Vercel ビルドが `/_not-found` prerender で `auth/invalid-api-key` で落ちる (admin で既知) | `getAuth` 等をモジュール top-level で呼ぶと SSG 評価時に env 不足で死ぬ | `src/lib/firebase/client.ts` で `firestore()` / `storage()` を **遅延初期化関数** にしてある (viewer はそもそも auth は要らないが、SSG プリレンダ時の防御として同じ書き方) |
| Vercel の env に値を貼ると `<value>` のように `<>` が混入 | プレースホルダ表記をそのままコピペ | env 値に `<` `>` は付けない |
| Firestore に書こうとして "Function setDoc() called with invalid data" | viewer では起きないはずだが、もし将来書込みを足すなら admin の `mappers.ts` の `compact()` 相当を viewer にも導入する必要 | viewer の `mappers.ts` は read 片道なので `compact()` 不採用 |
| Vercel preview / production で Firestore からアイテムが返ってこない | env 6 つを Production / Preview / Development 3 環境すべてに入れていない、または値が誤り | Vercel ダッシュボードの Environment Variables を確認 |
| iOS Safari で datetime-local 入力が viewport を突破する (admin で既知) | viewer に datetime-local は今のところ無いので無関係 | 将来フォームを足したときに `grid-cols-1 sm:grid-cols-2` で stack、`min-w-0 max-w-full`、`AppShell` main の `overflow-x-hidden` (現存) で対処 |
| 戻るボタンを押すと意図しない画面に戻る | viewer は階層が浅いので現状無関係 | 将来増やすときは `AppShell.parentHref()` を拡張、`router.replace` で履歴を汚さない |
| `grep -r "setDoc\|updateDoc\|deleteDoc\|uploadBytes" .next/` でヒットが出る | source map (`.js.map`) には Firestore SDK 内部のシンボル名が含まれる | `.js` バンドルだけ grep する: `grep -r --include='*.js'` で 0 件なら OK。実際の bundle に出る `runTransaction` は SDK のオフライン永続化レイヤの内部メソッドで、public API の write 呼び出しではない |

---

## 9. 検証コマンド

```bash
pnpm install
pnpm dev          # http://localhost:3000
pnpm build        # 型チェック + プロダクションビルド
pnpm lint
```

UI 変更を含む場合は dev サーバ起動 + ブラウザで操作確認すること (CLAUDE.md / AGENTS.md の指示)。動作確認の典型 4 段:

1. ホーム → admin 側で登録済アイテムが一覧に出る (Firestore 接続できているか)
2. アイテムタップ → 詳細ページに遷移、icon と main image が表示される
3. 戻るボタン → ホームに戻る (履歴ではなく `AppShell.parentHref()` 経由)
4. 検索 / カテゴリ / タグフィルタ / ソートが効く

bundle に書込み API が含まれていないことの確認:

```bash
pnpm build
# Firestore 書き込みは依然ゼロ
grep -r --include='*.js' -E 'setDoc|updateDoc|deleteDoc' .next/               # 0 件であること
# auth は持ち込んでいない
grep -lr --include='*.js' -E 'signInWithPopup|GoogleAuthProvider' .next/      # ヒット無しであること
# uploadBytes は v0.2.0 以降 inbox upload で意図的に使うため bundle に含まれて OK
# (`src/lib/inboxUpload.ts` 以外から呼んでいないことを確認したい場合)
grep -rn 'uploadBytes' src/                                                   # inboxUpload.ts のみであること
```

---

## 10. 未着手 / 今後の候補

### 完了済 (履歴用)

- **Storage Rules で受信BOX upload の size / contentType を server-side 制限** (v0.2.0 で依頼 → v0.3.0 リリース時に admin がデプロイ済)
  - 最終形は §3 のセキュリティルール参照 (`request.resource.size <= 10MB` + `image/(jpeg|png|webp)` のみ許可)
  - viewer 側の事前チェックは UX (即時フィードバック) として継続。改変クライアントは Storage Rules で弾かれる二段構え

### Phase 4 (HANDOFF 計画書 §10 より)
- **Vercel に新規プロジェクトとしてインポート** + env 登録 + Firebase Console > Authentication > 承認済みドメインに viewer ドメイン追加 (auth は使わないが将来用)
- **404 ページ** (Next.js のデフォルト `not-found.tsx` を Atelier 化)
- **OG meta** (タイトル / 説明 / og:image — Vercel OG image generation を使うかは後で判断)
- **`<img>` → `next/image` への置き換え** (`ItemCard` / 詳細の `AtelierThumb` / `AtelierHero`)。次/image は `<Image fill>` + `sizes` の使い分けを検討
- **PWA 微調整** — 実機で `/icon.svg` を SVG のまま PWA 設定に使えるか確認、必要なら PNG 192/512 を追加

### Atelier 関連で次ラウンドが来そうな箇所
- 画像長押しで保存 (詳細ヘロー)
- 価格エントリの並び順をユーザー側で切替 (現状 `sortedPriceEntries` は固定)
- ホーム一覧の URL クエリ同期 (検索 / フィルタ / ソートを `?q=...&sort=...` で永続化、シェアしやすく)

### admin と同期しないこと
- viewer は今後 admin と独立に進化させる方針。admin で UI が変わっても自動追従しない
- 例外は **データモデルの破壊変更** で、`types.ts` を viewer 側で手動追従する必要がある

---

## 11. 新セッション開始時のチェックリスト

1. このファイル全文を読む
2. `git status` / `git log -5 --oneline` / `git branch --show-current` を確認
3. `src/lib/version.ts` の最新バージョンと変更履歴を読む
4. `node_modules/next/dist/docs/` で関連 Next.js 16 ガイドを確認 (該当箇所を触るとき)
5. ユーザーの最初の要望を聞いてから動く (先回りで実装しない)
