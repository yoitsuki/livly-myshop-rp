"use client";

import { usePathname } from "next/navigation";
import AppHeader from "./AppHeader";
import { APP_VERSION } from "@/lib/version";

/**
 * Resolves the "parent" path for the back button. Item detail → home; the
 * upload page also surfaces a back arrow to home so users can bail out of
 * the picker without going through history.
 */
function parentHref(pathname: string): string | null {
  const itemMatch = pathname.match(/^\/items\/([^/]+)(\/.*)?$/);
  if (itemMatch) {
    const [, , rest] = itemMatch;
    if (!rest) return "/";
  }
  if (pathname === "/inbox" || pathname.startsWith("/inbox/")) return "/";
  return null;
}

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname() ?? "/";
  const backHref = parentHref(pathname);
  const showVersionFooter = pathname === "/";
  const onInbox = pathname === "/inbox" || pathname.startsWith("/inbox/");

  return (
    <div className="min-h-dvh flex flex-col">
      <AppHeader
        back={!!backHref}
        backHref={backHref ?? undefined}
        hideUpload={onInbox}
      />
      <main className="flex-1 w-full max-w-screen-sm mx-auto px-4 pb-24 pt-2 overflow-x-hidden">
        {children}
      </main>
      {showVersionFooter ? (
        <footer
          className="w-full max-w-screen-sm mx-auto px-4 py-3 text-center text-[var(--color-muted)] border-t border-[var(--color-line)] tabular-nums"
          style={{
            fontFamily: "var(--font-label)",
            fontSize: 10.5,
            letterSpacing: "0.04em",
          }}
        >
          ver. {APP_VERSION}
        </footer>
      ) : null}
    </div>
  );
}
