import type { Item, PriceEntry } from "./types";

function comparePriceEntriesDesc(a: PriceEntry, b: PriceEntry): number {
  const ay = a.shopPeriod?.yearMonth ?? "";
  const by = b.shopPeriod?.yearMonth ?? "";
  if (ay !== by) return ay > by ? -1 : 1;
  const ap = a.shopPeriod?.phase === "lastDay" ? 1 : 0;
  const bp = b.shopPeriod?.phase === "lastDay" ? 1 : 0;
  if (ap !== bp) return bp - ap;
  return b.checkedAt - a.checkedAt;
}

export function sortedPriceEntries(
  item: Pick<Item, "priceEntries">,
): PriceEntry[] {
  return [...(item.priceEntries ?? [])].sort(comparePriceEntriesDesc);
}

export function latestPriceEntry(
  item: Pick<Item, "priceEntries">,
): PriceEntry | undefined {
  if (!item.priceEntries || item.priceEntries.length === 0) return undefined;
  return sortedPriceEntries(item)[0];
}

/** Resolved 情報元 label for list/detail display.
 *  - メイン画像あり → "マイショ"
 *  - メイン画像なし + priceSource あり → "なんおし" / "その他" 等
 *  - メイン画像なし + priceSource なし (旧データ) → "設定無し" */
export function infoSourceLabel(
  item: Pick<Item, "priceEntries" | "mainImageUrl">,
): string {
  if (item.mainImageUrl) return "マイショ";
  const latest = latestPriceEntry(item);
  return latest?.priceSource?.trim() || "設定無し";
}
