import type { DocumentData } from "firebase/firestore";
import type { Item, Tag } from "./types";
import { normalizeTagType } from "@/lib/tagTypes";

export function itemFromFs(id: string, data: DocumentData): Item {
  return {
    id,
    iconUrl: data.iconUrl,
    iconStoragePath: data.iconStoragePath,
    mainImageUrl: data.mainImageUrl,
    mainImageStoragePath: data.mainImageStoragePath,
    iconCrop: data.iconCrop,
    mainCrop: data.mainCrop,
    name: data.name ?? "",
    category: data.category ?? "",
    tagIds: Array.isArray(data.tagIds) ? data.tagIds : [],
    minPrice: typeof data.minPrice === "number" ? data.minPrice : 0,
    priceEntries: Array.isArray(data.priceEntries) ? data.priceEntries : [],
    createdAt: typeof data.createdAt === "number" ? data.createdAt : 0,
    updatedAt: typeof data.updatedAt === "number" ? data.updatedAt : 0,
    isReplica: data.isReplica === true ? true : undefined,
  };
}

export function tagFromFs(id: string, data: DocumentData): Tag {
  return {
    id,
    name: data.name ?? "",
    type: normalizeTagType(data.type),
    color: data.color,
    displayOrder:
      typeof data.displayOrder === "number" ? data.displayOrder : undefined,
    createdAt: typeof data.createdAt === "number" ? data.createdAt : 0,
  };
}
