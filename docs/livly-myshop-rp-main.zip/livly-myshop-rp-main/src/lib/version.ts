/**
 * App version. Bump on each user-visible change.
 *
 * 0.6.1  Sync with admin v0.26.5: fix a flash of EmptyState during the home
 *        list's first paint. Treat `items === undefined` from useItems() as
 *        loading and replace the count/sort row + EmptyState/list with a
 *        Loader2-based LoadingState so 「まだアイテムがありません」/「条件に
 *        合うアイテムはありません」 never appears before the first snapshot.
 *        SearchBar + 絞込み button stay above; hasAnyFilterUI is already
 *        totalCount-gated so the button auto-hides while loading.
 * 0.6.0  Sync with admin v0.25.0: add a クリア button to the home filter panel.
 *        Shown only when activeFilterCount > 0, the bar sits at the very top
 *        of the panel as 「絞込み中 N 件 [× クリア]」 and resets replicaFilter
 *        to 'all', activeCategory to null, and activeTagIds to []. q
 *        (SearchBar) is intentionally preserved so users can keep their search
 *        text while dropping just the panel-level filters; the bar
 *        auto-hides once activeFilterCount returns to 0.
 * 0.5.1  Sync with admin v0.19.1: ItemCard 参考価格 row split into two tiers
 *        (label / price + GP + period badge) so 5–6-digit prices no longer
 *        wrap onto a second line. Both tiers use lineHeight: 1 with a 3px
 *        gap so the label and price read as one cluster, and 最低価格 sits
 *        8px below to read as a separate metric. PeriodBadge (list + detail)
 *        slimmed: fontSize 9.5→9, tracking 0.16em→0.08em, padding 8px→5px.
 * 0.5.0  Sync with admin v0.19.0: append an 情報元 chip to the tag row on the
 *        home list and the detail page. InfoSourceChip is a TagChip-shaped pill
 *        with a white background, muted text, 0.5px hairline border and zero
 *        radius. Label resolves via infoSourceLabel(item) — メイン画像あり →
 *        マイショ, otherwise the latest priceEntry.priceSource (なんおし / その他),
 *        falling back to 設定無し for legacy data with neither. Always rendered
 *        so empty-tag items still surface the info source.
 * 0.4.0  Sync with admin v0.18.0–v0.18.2: read `isReplica` from Firestore so
 *        replica items can be told apart from 原本 (game-internal naming —
 *        not "本物"). Show a hairline REPLICA badge under the thumb on the
 *        home list and to the right of the title block on the detail page.
 *        Home filter UI is reorganised behind a 絞込み toggle button (with an
 *        active-filter count badge) — the panel collapses category, the new
 *        replica segmented control (両方 / 原本のみ / レプリカのみ), and a
 *        per-tag-type collapsible section with a smart 全て選択 / 全て解除
 *        toggle, so the home first view is just the search bar, item count,
 *        and list.
 * 0.3.0  /inbox shows a thumbnail preview the moment files are picked
 *        (createObjectURL, with an icon fallback for HEIC where the browser
 *        can't decode it). Tag system synced with admin v0.15.0–v0.17.5:
 *        TagType expanded to 7 (gacha/bazaar/nuts/gradely/collab/creators/
 *        other), Tag.displayOrder added, useTags() now stable-sorted by
 *        TYPE_ORDER → displayOrder → createdAt, home filter is grouped per
 *        type with item-count badges and hides empty groups, tag chips use
 *        the new TYPE_COLORS palette. gacha label is now "ニューマハラ
 *        ショップ".
 * 0.2.0  Add inbox upload: header upload icon → /inbox sends images to
 *        Storage `inbox/` for the admin app's bulk import pipeline. HEIC is
 *        re-encoded to JPEG client-side. Drawer nav removed; version footer
 *        relocated to the home page.
 * 0.1.0  Initial viewer scaffold: read-only home + detail backed by Firestore,
 *        Atelier theme cloned from the admin app (livly-myshop-rp-m v0.13.0).
 */
export const APP_VERSION = "0.6.1";
